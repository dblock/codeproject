using System.Web.UI.WebControls;
using System.Web.UI;

namespace DirtyPanelExtender
{
    class DirtyPanelExtenderDesigner : AjaxControlToolkit.Design.ExtenderControlBaseDesigner<DirtyPanelExtender>
    {


    }
}
